---
name: Aura Premium AI Workspace
colors:
  surface: '#141218'
  surface-dim: '#141218'
  surface-bright: '#3b383e'
  surface-container-lowest: '#0f0d13'
  surface-container-low: '#1d1b20'
  surface-container: '#211f24'
  surface-container-high: '#2b292f'
  surface-container-highest: '#36343a'
  on-surface: '#e6e0e9'
  on-surface-variant: '#cbc4d2'
  inverse-surface: '#e6e0e9'
  inverse-on-surface: '#322f35'
  outline: '#948e9c'
  outline-variant: '#494551'
  surface-tint: '#cfbcff'
  primary: '#cfbcff'
  on-primary: '#381e72'
  primary-container: '#6750a4'
  on-primary-container: '#e0d2ff'
  inverse-primary: '#6750a4'
  secondary: '#cdc0e9'
  on-secondary: '#342b4b'
  secondary-container: '#4d4465'
  on-secondary-container: '#bfb2da'
  tertiary: '#e7c365'
  on-tertiary: '#3e2e00'
  tertiary-container: '#c9a74d'
  on-tertiary-container: '#503d00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#cfbcff'
  on-primary-fixed: '#22005d'
  on-primary-fixed-variant: '#4f378a'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#cdc0e9'
  on-secondary-fixed: '#1f1635'
  on-secondary-fixed-variant: '#4b4263'
  tertiary-fixed: '#ffdf93'
  tertiary-fixed-dim: '#e7c365'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#141218'
  on-background: '#e6e0e9'
  surface-variant: '#36343a'
typography:
  display:
    fontFamily: DM Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: DM Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: DM Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  body-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  label-caps:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.08em
  label-sm:
    fontFamily: DM Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-padding: 32px
  sidebar-width: 260px
---

## Brand & Style

The design system is a cinematic, dark-first environment optimized for deep work and high-level cognitive tasks. It draws inspiration from high-end professional hardware interfaces and modern editorial design, prioritizing operational focus over decorative flair.

The aesthetic is characterized by:
- **Intelligent Minimalism:** Function is paramount. Visual noise is eliminated to let AI-generated insights and user content take center stage.
- **Layered Depth:** Instead of flat surfaces, the system uses subtle shifts in dark indigo and charcoal-violet tones to establish hierarchy.
- **Atmospheric Lighting:** Depth is communicated through ambient radial gradients and soft vignette edges, simulating the way light behaves on physical matte surfaces.
- **Refined Precision:** Every interaction feels deliberate, with micro-transitions and focus states that provide immediate, calm feedback.

## Colors

The palette is anchored in deep, ink-like tones that reduce eye strain and create a "theatrical" backdrop for content.

- **Primary Background (#0A0A0F):** The base "void" layer, used for main application backgrounds.
- **Surface Layers (#12121A):** Used for sidebars, cards, and modal containers to create a subtle lift from the base.
- **The Accent Spectrum:** Transitions from the energetic **Deep Amethyst** for primary actions to **Muted Ultraviolet** and **Midnight Indigo** for secondary elements. **Soft Lavender** is reserved for high-contrast highlights and active text states.
- **Atmospheric Gradients:** Use radial gradients (e.g., a subtle 15% opacity Amethyst glow in the top-left corner) to break up large dark surfaces without introducing neon brightness.

## Typography

This design system utilizes **DM Sans** exclusively to maintain a clean, geometric, and modern feel. The hierarchy is "spacious and confident," meaning we rely on generous line heights and distinct weight contrasts rather than font-size variety alone.

- **Headings:** Apply subtle negative tracking (`-0.01em` to `-0.03em`) to larger headings to create a tightly-knit, premium appearance.
- **Labels:** Use `label-caps` for section headers in sidebars and metadata tags to provide clear structural signposts.
- **Body Text:** Ensure body text never hits pure white; use `neutral_text` (#E2E2E9) for maximum readability against dark backgrounds.

## Layout & Spacing

The layout is inspired by professional suite software (Apple Pro Apps, Linear), utilizing a structured 12-column grid for content areas and a fixed-width navigation sidebar.

- **The 8px Rhythm:** All padding, margins, and component heights follow an 8px base unit (with 4px increments for micro-adjustments).
- **Spaciousness:** Large content areas should use `xl` (40px) padding to maintain an "editorial" feel, preventing the AI workspace from feeling cluttered or data-heavy.
- **Adaptive Reflow:** On tablet, the sidebar collapses into a rail or drawer, and container padding reduces to `md` (16px). On mobile, the grid shifts to a single column with a bottom-tab navigation system.

## Elevation & Depth

Depth in this design system is achieved through "Tonal Stacking" rather than traditional drop shadows.

- **Level 0 (Base):** #0A0A0F. Used for the main app canvas.
- **Level 1 (Surfaces):** #12121A. Used for sidebars and panels. These surfaces use a `1px` inner border with `10% white` opacity to simulate a light-catching edge.
- **Level 2 (Modals/Popovers):** These elements use a subtle backdrop blur (12px) and a faint violet-tinted shadow (`rgba(0, 0, 0, 0.5)` with an `80px` blur) to feel as though they are floating in an atmospheric space.
- **Soft Vignettes:** Apply a 10% radial gradient overlay to the entire screen, darkening the corners to draw the eye toward the center of the workspace.

## Shapes

The shape language is "Rounded," striking a balance between the technical precision of sharp corners and the friendliness of circles.

- **Default Radius (8px):** Applied to standard buttons, input fields, and small cards.
- **Large Radius (16px):** Applied to main workspace containers and large modal sheets.
- **Extra Large Radius (24px):** Used for "AI Insight" bubbles or special highlight containers to make them feel distinct and organic.

## Components

Components should feel like high-precision instruments.

- **Buttons:** 
  - *Primary:* A solid `Deep Amethyst` to `Ultraviolet` linear gradient (top-to-bottom). No heavy glow, just a clean 1px border of `Soft Lavender` at 20% opacity.
  - *Secondary:* Ghost style with a `12% white` fill on hover and a subtle indigo stroke.
- **Inputs:** Darker than the surface background (#07070A) with a `1px` stroke. Upon focus, the stroke transitions to `Deep Amethyst` with a very soft, `2px` amethyst outer glow.
- **Cards:** No background color on primary cards; instead, use a `1px` stroke of #1A1A24 and a subtle `4px` corner radius.
- **Chips/Badges:** Use `Soft Lavender` text on a `10% opacity Lavender` background for a refined, readable tag system.
- **AI Focus State:** Any element currently being processed or "thought about" by the AI should feature a slow-pulsing radial gradient edge in `Soft Lavender`.